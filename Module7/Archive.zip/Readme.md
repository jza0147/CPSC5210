# CPSC 5210: Auction Project

This file explains the use of the auction site.  This is a simple auction site for administering auctions for small to medium size auctions. 

## 📋 Table of Contents
- [About the Project](#about-the-project)
- [Directory Structure](#directory-structure)
- [Getting Started](#getting-started)
- [Prerequisites](#prerequisites)
- [Technologies Used](#technologies-used)

## 📖 About the Project
This project does not require any software other than a browser and a free copy of XAMMP. This software will run the website locally and allow multiple users access to the system.  It also must be setup for this local server.  The file db.php must be changed to the ip address of the computer hosting the XAMMP program. After the initial setup, this system works very well.  

## 🗂️ Directory Structure
An overview of how your files are organized:
```text

├── Module7/
│   └── (module 7 files)
├── .gitignore
└── README.md
```

## 🚀 Getting Started
Step-by-step instructions on how to get your development environment running locally.

### Prerequisites
List the software or tools needed to run this project:
*   [XAMPP](https://apachefriends.org) (for Apache and MySQL execution)
*   Web Browser (Chrome, Firefox, Safari)
*   VS Code or a text editor of choice

### Local Installation
1. Clone the repository to your local machine:
   ```bash
   git clone https://github.com/jza0147/CPSC5210.git
   ```
2. Move the project folder into your XAMPP local host directory (e.g., `htdocs`).
3. Open your browser and navigate to `http://localhost/CPSC5210/Module2/index.html`.

## 🛠️ Technologies Used
*   **HTML5 / CSS3** — Frontend layout and Flexbox columns
*   **PHP** — Backend database connections and scripting
*   **MySQL** — Database storage and structured queries
*   **Git / GitHub** — Version control and repository hosting
